
import React from "react";
import Image from "next/image";
import Link from "next/link";
import Navigation from "@/components/sections/navigation";

const LOGO_URL = "/logo/Logo.png";

function Slide({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  
  // Normal page sections (no snap / full-screen locking)
  return (
    <section
      className={`bg-ivory text-charcoal py-7 sm:py-9 md:py-12 lg:py-14 xl:py-16 ${className}`}
    >
      <div className="mx-auto w-full max-w-[1035px] px-5 sm:px-7 lg:max-w-[1150px] xl:max-w-[1265px] 2xl:max-w-[1380px]">
        {children}
      </div>
    </section>
  );
}

export default function AboutPage() {
  
  return (
    <main className="bg-ivory text-charcoal">
      {/* Navbar (on top) */}
      <div className="relative z-50">
        <Navigation />
      </div>

      {/* Slide 1: Hero section with fixed overlapping */}
      <section className="text-charcoal bg-white pt-0 pb-0">
        <div className="full-bleed">
          <div className="flex flex-col lg:grid lg:grid-cols-[480px_1fr] xl:grid-cols-[520px_1fr] 2xl:grid-cols-[560px_1fr]">
            {/* LEFT: big image */}
            <div className="relative order-2 h-[40vh] bg-white sm:h-[52vh] lg:order-1 lg:h-[100vh] xl:h-[100vh] 2xl:h-[100vh]">
              <Image
                src="/about-page/slide1/main.jpg"
                alt="Wedding Goosebumps"
                fill
                className="object-cover object-center"
                loading="eager"
                priority
              />
            </div>

            {/* RIGHT: content with no overlap */}
            <div className="order-1 flex min-h-[58vh] flex-col justify-center bg-white px-5 py-9 sm:px-7 sm:py-12 lg:order-2 lg:h-full lg:px-7 lg:py-0 lg:pr-5 xl:px-9 xl:pr-7">
              {/* Wordmark */}
              <div className="mb-6 text-center lg:mb-7">
                <h2 className="font-commuter-sans text-[10px] tracking-[0.3em] uppercase sm:text-[12px] md:text-[13px]">
                  WEDDING GOOSEBUMPS
                </h2>
              </div>

              {/* Four images row - ensure they don't get cut */}
              <div className="mb-6 grid grid-cols-2 gap-3 sm:grid-cols-4 sm:gap-4 lg:mb-8 lg:gap-5">
                {[
                  "/about-page/slide1/1.jpg",
                  "/about-page/slide1/2.jpg",
                  "/about-page/slide1/4.jpg",
                  "/about-page/slide1/3.jpg",
                ].map((src, idx) => (
                  <div key={idx} className="relative aspect-[3/4] overflow-hidden bg-[#efe9df]">
                    <Image
                      src={src}
                      alt={`Gallery ${idx + 1}`}
                      fill
                      className="object-cover"
                      loading={idx < 4 ? "eager" : "lazy"}
                      priority={idx < 4}
                    />
                  </div>
                ))}
              </div>

              {/* Headline + subcopy */}
              <div className="max-w-[680px]">
                <h1 className="font-epicene-display mb-3.5 text-[25px] leading-[1.08] font-light uppercase sm:text-[32px] md:text-[37px] lg:text-[41px] xl:text-[46px]">
                  WEDDING GOOSEBUMPS
                </h1>
                <p className="font-commuter-sans text-charcoal/85 mb-3.5 text-[10px] tracking-[0.3em] uppercase sm:text-[12px] md:text-[13px]">
                  FULL SERVICE DESTINATION WEDDING AND <br className="hidden sm:block" />
                  DESIGN BOUTIQUE
                </p>
                <div className="mb-4 h-[2px] w-12 bg-[#D9D5CF] sm:mb-5 sm:w-14" />
                <p className="font-lora text-charcoal/90 text-[15px] leading-[1.7] sm:text-[16px] sm:leading-[1.8] md:text-[17px]">
                  We serve a discerning global clientele who seek more than just a wedding
                  <i>— they seek an unforgettable experience.</i> From first vision to final toast,
                  we navigate cultures, traditions, and trends with ease, creating celebrations that
                  are seamless, soulful, and spectacular in every detail.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Slide 2 - Fixed image cutting */}
      <Slide className="mt-12 lg:mt-16 xl:mt-20">
        <div className="mx-auto w-full max-w-[1000px] px-5 sm:px-7">
          <div className="grid items-start gap-[2.188rem] lg:grid-cols-[400px_1fr] lg:gap-[2.688rem] xl:grid-cols-[440px_1fr] xl:gap-[3.188rem]">
            {/* Left image - ensure proper aspect ratio */}
            <div className="relative h-[430px] w-full overflow-hidden bg-[#efe9df] sm:h-[510px] lg:h-[650px] xl:h-[650px]">
              <Image
                src="/about-page/slide2/Photo.jpg"
                alt="Ali Waris Khan"
                fill
                className="object-cover object-center"
                loading="eager"
                priority
              />
            </div>

            {/* Right text column */}
            <div className="mt-3 max-w-[540px] lg:mt-4 lg:pl-0.5">
              <p className="font-cormorant text-charcoal/80 mb-6 text-[16px] italic sm:text-[17px] md:text-[18px]">
                Ali has been creating luxury weddings and events since 2010
              </p>

              <p className="font-lora text-charcoal/90 mb-7 text-justify text-[16px] leading-[1.7] sm:text-[17px] sm:leading-[1.75] md:text-[18px]">
                With over 15 years in the luxury wedding world, Ali Waris Khan has become one of the
                most trusted names in destination wedding planning and design across India and
                beyond. His approach is rooted in a deep respect for each couple's story, blending
                meticulous planning with an intuitive sense of style and emotion. Over the years, he
                has built strong relationships with the finest venues, artisans, and creative
                collaborators, ensuring every celebration is not only flawlessly executed but also a
                true reflection of the couple's personality, heritage, and dreams.
              </p>

              <h2 className="font-epicene-display mb-7 text-[25px] leading-[1.15] font-light tracking-wide uppercase sm:text-[30px] md:text-[35px] lg:text-[37px]">
                His Approach To Wedding <span className="font-light lowercase italic">and</span>{" "}
                Design
              </h2>

              <p className="font-lora text-charcoal/80 text-justify text-[14px] leading-[1.7] italic sm:text-[15px] md:text-[16px]">
                Is different in that he offers his couples a truly hands-on experience. He accepts a
                limited number of weddings per year, which allows him to give 100% of his attention
                to each and every couple.
                <br />
              </p>
            </div>
          </div>
        </div>
      </Slide>

      {/* Decorative divider with infinity symbol */}
      <div className="bg-ivory py-8 pb-[30px] sm:py-10 sm:pb-[38px] md:py-12 md:pb-[46px]">
        <div className="mx-auto flex max-w-4xl items-center gap-3 px-6 sm:gap-4">
          <div className="bg-charcoal/20 h-px flex-1" />
          <span className="text-2xl text-[#B5A484] sm:text-3xl">∞</span>
          <div className="bg-charcoal/20 h-px flex-1" />
        </div>
      </div>

      {/* Slide 3 — Framed statement panel with mobile improvements */}
      <Slide>
        <div className="mt-2 mb-10 w-full sm:mt-5 sm:mb-15 lg:mt-8 lg:mb-20 xl:mt-10 xl:mb-24">
          <div className="border-charcoal/10 mx-auto max-w-5xl border bg-white px-4 py-6 shadow-sm sm:px-6 sm:py-8 md:px-8 md:py-10">
            {/* top divider with monogram */}
            <div className="mb-3 flex items-center gap-3 sm:mb-4 sm:gap-4">
              <div className="bg-charcoal/20 h-px flex-1" />
              <span className="font-epicene-display text-lg text-[#B5A484] italic sm:text-xl md:text-2xl">
                WG
              </span>
              <div className="bg-charcoal/20 h-px flex-1" />
            </div>

            {/* small uppercase kicker */}
            <p className="font-commuter-sans text-charcoal/70 mb-2 text-center text-[8px] tracking-[0.25em] uppercase sm:mb-3 sm:text-[9px] md:text-[10px]">
              WE OFFER BESPOKE EVENT PLANNING SERVICES
            </p>

            {/* big centered headline (responsive size) */}
            <h3 className="font-newsreader text-charcoal mx-auto max-w-2xl text-center text-[12px] leading-[1.4] tracking-[0.05em] uppercase sm:text-[13px] sm:leading-[1.5] sm:tracking-[0.06em] md:text-[15px] lg:text-[17px]">
              TAILORED TO FIT THE NEEDS OF HIS CLIENTS AND GOES ABOVE AND BEYOND TO CRAFT A
              SEAMLESSLY EXECUTED WEDDING PLANNING AND DESIGN EXPERIENCE FOR HIS COUPLES AND THEIR
              GUESTS.
            </h3>

            {/* button */}
            <div className="mt-5 flex justify-center sm:mt-6">
              <Link
                href="/inquire"
                className="font-lora inline-flex items-center justify-center bg-[#C2A770] px-6 py-2 text-[10px] tracking-[0.18em] text-white uppercase transition-colors hover:bg-[#B79A63] sm:px-8 sm:py-3 sm:text-xs"
              >
                GET IN TOUCH
              </Link>
            </div>
          </div>
        </div>
      </Slide>

      {/* Slide 4 — Fixed mobile layout and image cutting */}
      <Slide className="bg-white">
        <div className="full-bleed">
          {/* Mobile: stack vertically with proper spacing */}
          <div className="flex flex-col gap-6 lg:grid lg:grid-cols-[240px_1fr_380px] lg:gap-6 xl:grid-cols-[280px_1fr_480px] xl:gap-8">
            {/* LEFT IMAGE - hidden on mobile, proper height on desktop */}
            <div className="relative hidden h-[360px] w-full overflow-hidden lg:mt-12 lg:block lg:h-[380px] xl:h-[430px]">
              <Image
                src="/about-page/slide-4/1.jpg"
                alt="Earlier work"
                fill
                className="object-cover object-center"
                loading="lazy"
              />
            </div>

            {/* TEXT BLOCK - separate on mobile */}
            <div className="relative px-4 py-6 sm:px-6 lg:px-6 lg:py-12">
              {/* Mobile label */}
              <p className="font-commuter-sans text-charcoal/50 mb-4 text-[9px] tracking-[0.3em] uppercase sm:text-[10px] lg:hidden">
                HOW IT ALL STARTED
              </p>

              {/* Vertical label - desktop only */}
              <div className="pointer-events-none absolute top-16 bottom-4 left-3 hidden lg:block">
                <div className="bg-charcoal/15 h-full w-px" />
                <span
                  className="text-charcoal/50 absolute top-6 ml-2 text-[9px] tracking-[0.35em] uppercase"
                  style={{ writingMode: "vertical-rl", transform: "rotate(180deg)" }}
                >
                  HOW IT ALL STARTED
                </span>
              </div>

              <div className="pr-12 lg:pl-12 xl:pl-16">
                <h3 className="font-epicene-display mb-6 text-[22px] leading-[1.15] font-light uppercase sm:text-[26px] md:text-[28px] lg:mb-8 lg:text-[30px]">
                  Prior to starting his own business,
                </h3>

                <p className="font-lora text-charcoal/90 mb-8 text-justify text-[13px] leading-[1.7] sm:text-[14px] sm:leading-[1.8] md:text-[14.5px] lg:mb-10">
                  Before founding Wedding Goosebumps, Ali spent years as the Director of a leading
                  events and entertainment company, delivering spectacular celebrations across India
                  and abroad. This role refined his{" "}
                  <em>
                    expertise in managing large-scale, high-profile events with precision,
                    creativity, and cultural sensitivity.
                  </em>{" "}
                  <br />
                  <br />
                  His ability to remain calm under pressure, think strategically, and adapt
                  seamlessly to diverse settings ensures every wedding — whether in a royal palace,
                  a serene beach resort, or an international destination — is flawlessly executed.
                  Paired with his innate design sensibility and passion for storytelling, Ali offers
                  couples a world-class, five-star experience that transcends borders.
                </p>

                <Link
                  href="/inquire"
                  className="font-lora inline-flex items-center justify-center border border-[#C2A770] px-5 py-2 text-[10px] tracking-[0.2em] text-[#C2A770] uppercase transition-colors hover:bg-[#C2A770] hover:text-white sm:text-xs"
                >
                  Get in touch
                </Link>
              </div>
            </div>

            {/* RIGHT IMAGE - proper height, no cutting */}
            <div className="relative h-[50vh] overflow-hidden bg-[#efe9df] lg:h-[75vh] xl:h-[75vh]">
              <Image
                src="/about-page/slide-4/2.jpg"
                alt="Events"
                fill
                className="object-cover object-center"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </Slide>

      {/* Slide 5 - Video with responsive height */}
      <Slide className="m-0 p-0">
        <div className="full-bleed relative h-[50vh] sm:h-[60vh] md:h-[70vh] lg:h-[80vh] xl:h-[90vh]">
          <video
            src="/videos/about-page-vids/TATSAV VIDHI HIGHLIGHT 20sec 18.mp4"
            autoPlay
            muted
            loop
            playsInline
            className="h-full w-full object-cover"
          />
        </div>
      </Slide>

      {/* Slide 6 — Fixed testimonial layout */}
      <Slide className="py-16 lg:py-24">
        <div className="full-bleed">
          <div className="flex flex-col gap-6 lg:grid lg:grid-cols-[180px_1fr_380px] lg:gap-10 xl:grid-cols-[240px_1fr_480px]">
            {/* LEFT IMAGE - hidden on mobile, proper height */}
            <div className="relative hidden h-[320px] overflow-hidden bg-[#efe9df] lg:block lg:h-[400px] xl:h-[480px]">
              <Image
                src="/about-page/slide6/1.jpg"
                alt="Detail A"
                fill
                className="object-cover object-center"
                loading="lazy"
              />
            </div>

            {/* CENTER: testimonial block - separate on mobile */}
            <div className="relative px-4 py-6 text-left sm:px-6 lg:px-8 lg:py-10 lg:text-right xl:px-12">
              {/* Mobile label */}
              <p className="font-commuter-sans text-charcoal/50 mb-4 text-[9px] tracking-[0.3em] uppercase sm:text-[10px] lg:hidden">
                KIND WORDS
              </p>

              {/* vertical label - desktop only */}
              <div className="absolute top-16 right-0 bottom-8 hidden items-start lg:flex">
                <div className="bg-charcoal/15 h-full w-px" />
                <span
                  className="text-charcoal/50 mt-6 ml-3 text-[9px] tracking-[0.35em] uppercase"
                  style={{ writingMode: "vertical-rl", transform: "rotate(180deg)" }}
                >
                  KIND WORDS
                </span>
              </div>

              <div className="lg:-mt-15.5 lg:pr-6">
                <h5 className="text-charcoal mt-50 mb-6 text-[22px] leading-tight sm:text-[26px] md:text-[30px] lg:text-[34px]">
                  "Ali is truly a <br />
                  one-of-a-kind planner."
                </h5>
                <p className="font-newsreader text-charcoal/90 text-[14px] leading-[1.7] sm:text-[15px] sm:leading-[1.8] md:text-[16px]">
                  It would be an understatement to say he was instrumental in bringing our wedding
                  vision to life. Our planning journey with him was effortless, enjoyable, and
                  completely stress-free. Thank you, Ali, for turning our special day into an
                  unforgettable celebration.
                </p>
              </div>
            </div>

            {/* RIGHT IMAGE - proper height */}
            <div className="relative h-[50vh] overflow-hidden bg-[#efe9df] lg:h-[65vh] xl:h-[75vh]">
              <Image
                src="/about-page/slide6/main.jpg"
                alt="Testimonial main"
                fill
                className="object-cover object-center"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </Slide>

      {/* Slide 7 - Fixed image aspect ratios */}
      <Slide className="mt-16 !py-0 lg:mt-18">
        <div className="mx-auto flex max-w-none flex-col -space-y-1 px-2 sm:px-4 lg:flex-row lg:space-y-0 lg:-space-x-1">
          <div className="relative mx-auto h-[320px] max-w-[520px] flex-1 overflow-hidden sm:h-[400px] sm:max-w-[580px] lg:h-[610px] lg:max-w-[680px]">
            <Image
              src="/about-page/slide7/1.jpg"
              alt="Gallery Left"
              fill
              className="object-contain object-center"
              loading="lazy"
            />
          </div>
          <div className="relative mx-auto h-[320px] max-w-[520px] flex-1 overflow-hidden sm:h-[400px] sm:max-w-[580px] lg:h-[610px] lg:max-w-[680px]">
            <Image
              src="/about-page/slide7/2.jpg"
              alt="Gallery Right"
              fill
              className="object-contain object-center"
              loading="lazy"
            />
          </div>
        </div>

        {/* Text section - proper spacing */}
        <div className="relative flex flex-col items-start px-4 py-8 sm:px-6 lg:px-16 lg:py-12">
          {/* Vertical right label - desktop only */}
          <div className="absolute top-8 right-0 bottom-0 hidden items-start lg:flex">
            <div className="bg-charcoal/15 h-full w-px" />
            <span
              className="text-charcoal/50 mt-6 ml-3 text-[9px] tracking-[0.35em] uppercase"
              style={{ writingMode: "vertical-rl", transform: "rotate(180deg)" }}
            >
              VALUES
            </span>
          </div>

          {/* Main text */}
          <p className="text-charcoal/70 font-commuter-sans mb-2 text-[9px] tracking-[0.25em] uppercase sm:text-[10px] md:text-[11px]">
            WE BELIEVE IN
          </p>
          <h2 className="font-epicene-display text-charcoal mb-3 text-[30px] leading-tight sm:text-[36px] md:text-[40px]">
            APPROACHABILITY
          </h2>
          <p className="font-newsreader text-charcoal/90 mb-6 max-w-2xl text-[14px] leading-[1.7] sm:text-[15px] sm:leading-[1.8] md:text-[16px]">
            Our goal is to provide our clients with the utmost level of service throughout the
            planning and design process as there is never a question too big or too small.
          </p>
        </div>
      </Slide>

      {/* Slide 8 — Final CTA with responsive improvements */}
      <Slide className="full-bleed relative h-[60vh] overflow-hidden !py-0 sm:h-[65vh] md:h-[75vh] lg:h-[80vh] xl:h-[100vh]">
        {/* Full background image */}
        <Image
          src="/about-page/slide8/main.jpg"
          alt="Inquire Background"
          fill
          className="object-cover object-[50%_35%]"
          loading="lazy"
        />

        {/* Centered overlay with responsive text */}
        <div className="absolute inset-0 flex flex-col items-center justify-center px-4 text-center text-white [&_*]:!text-white">
          <h2 className="font-epicene-display text-[20px] leading-[1.06] font-light tracking-[0.05em] uppercase drop-shadow-[0_2px_8px_rgba(0,0,0,0.35)] sm:text-[26px] sm:tracking-[0.06em] md:text-[32px] lg:text-[38px]">
            Inquire to begin
          </h2>

          <Link
            href="/inquire"
            className="font-commuter-sans relative mt-3 inline-block text-[8px] tracking-[0.2em] uppercase transition after:mx-auto after:mt-2 after:block after:h-[1px] after:w-[110%] after:translate-x-[-5%] after:bg-white/90 after:content-[''] hover:after:bg-white sm:text-[9px] sm:tracking-[0.25em] md:text-[10px]"
          >
            Work with Us
          </Link>
        </div>
      </Slide>
    </main>
  );
}
