import { Metadata } from "next";
import prisma from "@/lib/prisma";

// Apne hisab se default values ko change kar lena
const DEFAULT_SEO = {
  title: "Wedding Goosebumps | Best Wedding Ideas, Inspiration & Planning",
  description: "Plan your dream wedding with Wedding Goosebumps. Discover breathtaking wedding ideas, decor inspiration, real stories, and expert tips to make your special day unforgettable.",
  keywords: "wedding inspiration, dream wedding ideas, wedding planning tips, wedding decoration ideas, bridal inspiration, wedding themes, modern wedding trends, wedding photography ideas, wedding blog, best wedding guide",
};

export async function getPageMetadata(slug: string): Promise<Metadata> {
  const page = await prisma.page.findUnique({
    where: { slug }
  });

  // Agar page hi nahi mila, toh pure website ka default SEO return kar do
  if (!page) {
    return {
      title: DEFAULT_SEO.title,
      description: DEFAULT_SEO.description,
      keywords: DEFAULT_SEO.keywords,
    };
  }

  // Fallback logic taaki empty tags me default text chala jaye
  const finalTitle = page.metaTitle || page.title || DEFAULT_SEO.title;
  const finalDescription = page.metaDescription || DEFAULT_SEO.description;
  const finalKeywords = page.metaKeywords || DEFAULT_SEO.keywords;

  return {
    title: finalTitle,
    keywords: finalKeywords,
    description: finalDescription,
    alternates: {
      canonical: page.canonicalUrl || undefined,
    },
    robots: page.robots || "index, follow",
    openGraph: {
      title: page.ogTitle || finalTitle,
      description: page.ogDescription || finalDescription,
      images: page.ogImage ? [{ url: page.ogImage }] : [],
    }
  };
}